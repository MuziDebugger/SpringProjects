package com.debugger.controller.insurance;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.domain.debugger.HomePage;

@Controller
@RequestMapping("/posts")
public class PageController {
	
	private static final Logger logger = LoggerFactory.getLogger(PageController.class);

	@SuppressWarnings("unused")
	@RequestMapping("/get/{slug}")
	public String getPost( @PathVariable(value="slug") String slug ) throws Exception {
		HomePage post = null;
		logger.debug("Could not find page: " + slug);
		if( post == null ) throw new Exception("We couldn't find the page: " + slug);
		return "index";
	}
}
