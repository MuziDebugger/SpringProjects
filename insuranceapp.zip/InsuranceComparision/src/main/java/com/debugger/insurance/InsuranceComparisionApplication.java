package com.debugger.insurance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceComparisionApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceComparisionApplication.class, args);
	}

}
